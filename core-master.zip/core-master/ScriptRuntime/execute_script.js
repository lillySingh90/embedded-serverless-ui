const vm = require('vm');

const sandbox = { payload: {}};


async function executeScript(code) {
  vm.createContext(sandbox);
  vm.runInContext(code, sandbox);
  console.log("the returnValue is: " + JSON.stringify(sandbox.payload));
  return JSON.stringify(sandbox.payload);
}

process.on('message', async(message) => {
  const theReturningJson = await executeScript(message.code);
  process.send({payload: theReturningJson});
});
