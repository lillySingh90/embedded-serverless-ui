const scriptDB = require('./../RestAPI/db/scripts');
const configFile = require('./../RestAPI/db/config');
const {fork} = require('child_process');
var process;


function triggerEvent(triggerId) {
    var successfullyExecuted = false;
    configFile.forEach((config) => {
        if(config.triggerId === triggerId) {
            successfullyExecuted = searchScriptandExecuteIt(config.triggerId);
        }
    })
    return successfullyExecuted;
}

function searchScriptandExecuteIt(scriptId) {
    return scriptDB.some((script) => {
        if(scriptId === script.id) {
          process = fork('./../ScriptRuntime/execute_script.js');
          process.send({code: script.code});
          process.on('message', (message) => {
            console.log("The message retrieved: " + JSON.stringify(message.payload));
            process.kill();
            process = null;
          })
          return;
        }
    })
}



module.exports = triggerEvent;
