const scriptRuntime = require('./../ScriptRuntime/triggerAScript');

var triggerId = 2;
scriptRuntime(triggerId);
