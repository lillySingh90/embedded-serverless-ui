let mongoose = require('mongoose');

const server = 'localhost:27017';
const database = 'embedded_serverless';

    function _connect() {
        mongoose.connect("mongodb://"+server+"/"+database,
        {useNewUrlParser: true}).then(() => {
            console.log('Database connection successful');
        }).catch((err) => {
            console.log('Database connection error: ' + err);
        })
    }


module.exports = _connect;