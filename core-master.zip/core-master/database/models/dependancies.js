const mongoose = require('mongoose');

const dependancySchema = mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    triggerId: mongoose.Schema.Types.ObjectId,
    scriptId: mongoose.Schema.Types.ObjectId
});

module.exports = mongoose.model('Dependancy', dependancySchema);
