const mongoose = require('mongoose');

const scriptSchema = mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    name: String,
    code: String
});

module.exports = mongoose.model('Script', scriptSchema);
