const mongoose = require('mongoose');

const plcSchema = mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    ip: String,
    mlfb: String
});

module.exports = mongoose.model('Plc', plcSchema);
