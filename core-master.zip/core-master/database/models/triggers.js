const mongoose = require('mongoose');

const triggerSchema = mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    plcId: mongoose.Schema.Types.ObjectId,
    variable: String
});

module.exports = mongoose.model('Trigger', triggerSchema);