const opcua = require("node-opcua"); // see http://node-opcua.github.io/api_doc/0.2.0/index.html
const path = require('path');
//const addAuditEntry = require('./add_audit_entry.js');

const addPlcAndTriggerInformationToDb = require('./../DatabaseInterface/addPlcAndTriggerToDb');
const connectToDatabase = require('./../../database/connectionDb');

connectToDatabase();

/*
forces all http requests to be sent to the proxy defined in the 
environment variables http_proxy / https_proxy
*/
// needed for fabric client http calls (e.g. admin/CA/Credential handling)
// but must be disabled when grpc is used
//var globalTunnel = require('global-tunnel-ng');
//globalTunnel.initialize();


const certdir = './../certificates';
const scalarValueRank = 1; // workaround for PLC bug. Normally this should be -1 but S7-1500 needs 1 here

//const ahn = "192.168.200.50";
const ahn = "192.168.200.20";

var server = new opcua.OPCUAServer({
    port: 4847,        // the port of the listening socket of the server
    nodeset_filename: opcua.standard_nodeset_file,
    certificateFile: path.join(certdir, 'opcuaserver_cert.pem'),
    allowAnonymous: true,
    privateKeyFile: path.join(certdir, 'opcuaserver_key.pem'),
    alternateHostname: ahn // TODO: important for PLC
});



// TODO: the list of CA root certificates should be set here to validate the client certificates
//    but when looking at http://node-opcua.github.io/api_doc/0.2.0/files/packages_node-opcua-secure-channel_src_server_server_secure_channel_layer.js.html#l1134
//    the validation has not been implemented yet...
// Let create an instance of OPCUAServer


// we can set the buildInfo
server.buildInfo.productName = "MySampleServer1";
server.buildInfo.buildNumber = "7658";
server.buildInfo.buildDate = new Date(2015, 12, 25);

// the server needs to be initialized first. During initialisation, the server will construct its default namespace.
server.initialize(function () {
    console.log("OPC UA Server initialized");

    // we can now extend the default name space with our variables
    construct_my_address_space(server);

    // we can now start the server
    server.start(function () {
        console.log("Server is now listening ... ( press CTRL+C to stop) ");
        var endpointUrl = server.endpoints[0].endpointDescriptions()[0].endpointUrl;
        server.endpoints[0].endpointDescriptions().forEach(function (endpoint) {
            console.log(endpoint.endpointUrl, endpoint.securityMode.toString(), endpoint.securityPolicyUri.toString());
        });

        /*addAuditEntry.Init(fabricConfig).then(function()
        {
            console.log("addAuditEntry successfully initialized");
        }).catch((e) =>  {
            console.log(`Error: addAuditEntry initialization failed: ${e}`);
            server.shutdown(5000);
        });*/
    })
});

function construct_my_address_space(server) {
    const addressSpace = server.engine.addressSpace;

    // we create a new folder under RootFolder
    // newer versions require the 'getOwnNamespace()'
    //var myDevice = addressSpace.getOwnNamespace().addFolder("ObjectsFolder", {browseName: "MyDevice"});
    var myDevice = addressSpace.addFolder("ObjectsFolder", { browseName: "MyDevice" });

    //addFunctionOpenDoor(addressSpace, myDevice);
    //addFunctionAddAuditEntry(addressSpace, myDevice);
    addFunctionRegisterTriggers(addressSpace, myDevice)
}


function addFunctionRegisterTriggers(addressSpace, myDevice) {
    console.log("Bind methode");
    var method = addressSpace.addMethod(myDevice, {
        browseName: "RegisterTrigger",
        inputArguments: [
            {
                name: "Trigger",
                description: { text: "a json list of all trigger. Use the format: ...." },
                dataType: opcua.DataType.String,
                valueRank: scalarValueRank // TODO: important for PLC
            },
            {
                name: "PLC",
                description: { text: "a json with this information: ip, name, mlfb" },
                dataType: opcua.DataType.String,
                valueRank: scalarValueRank
            }
        ]
    });
    method.inputArguments.userAccessLevel = opcua.makeAccessLevel("CurrentRead");
    method.bindMethod(function (inputArguments, context, callback) {
        console.log("I was called");
        const triggerList = FromOpcScalarValue(inputArguments[0].value);
        const plcInformation = FromOpcScalarValue(inputArguments[1].value);
        const plcId = 0;
        const callMethodResult = {
            statusCode: opcua.StatusCodes.Good,
        };

        //try {
        addPlcAndTriggerInformationToDb(JSON.parse(plcInformation), JSON.parse(triggerList))
            .then(() => {
                console.log("Fine");
                /*console.log("retunr data: " + returnData);
                const returnDataJson = JSON.parse(returnData);
                console.log("I am here");
                console.log("The success is: " + returnDataJson.success);
                if (returnDataJson.success == false) {
                    throw returnDataJson.err;
                }
                else {
                    plcId = returnDataJson.plcId;
                }
                console.log("Add trigger with id: "+ plcId);
                addTriggerToDb(JSON.parse(triggerList), plcId)
                    .then((returnDataTrigger) => {
                        if (returnData.success == false) {
                            throw returnData.err;
                        }
                    })
                    .catch((err) => {
                        callMethodResult.statusCode = opcua.StatusCodes.BadUnexpetedError;
                        console.log("Error while adding the triggers to the database: " + err);
                    });*/
            }).catch((err) => {
                callMethodResult.statusCode = opcua.StatusCodes.BadUnexpetedError;
                console.log("Error while adding the plc information to the database: " + err);
                callback(null, callMethodResult);
                return;
            });

        callback(null, callMethodResult);
        /*}
        catch (err) {
            callMethodResult.statusCode = opcua.StatusCodes.BadUnexpetedError;
            console.log("Error while adding the plc information to the database: " + err);
            callback(null, callMethodResult);
            return;
        }*/

        /*try {
            const returnData = addTriggerToDb(JSON.parse(triggerList), plcId);
            if (returnData.success == false) {
                throw returnData.err;
            }
        }
        catch (err) {
            callMethodResult.statusCode = opcua.StatusCodes.BadUnexpetedError;
            console.log("Error while adding the triggers to the database: " + err);
        }*/



    });
}


// depending on the value of scalarValueRank this returns either x 
// or an array with x as the only member.
function ToOpcScalarValue(x) {
    return (scalarValueRank == -1) ? (x) : [x];
}
function FromOpcScalarValue(x) {
    return (scalarValueRank == -1) ? x : x[0];
}
