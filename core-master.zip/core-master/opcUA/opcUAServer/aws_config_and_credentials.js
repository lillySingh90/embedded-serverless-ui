{ 
    "accessKeyId": "AKIAJ65WGCDXRJRV5Q7A",
    "secretAccessKey": "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", 
    "region": "us-west-2" 
}