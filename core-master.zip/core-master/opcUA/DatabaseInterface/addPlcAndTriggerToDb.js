const mongoose = require('mongoose');
const Plc = require("../../database/models/plcs");
const Trigger = require('../../database/models/triggers');

async function addPlcInfromationToDb(plcInforamtion, triggerList) {
    console.log("The plc information contains following: " + JSON.stringify(plcInforamtion));
    console.log("The ip adress: " + plcInforamtion.ip);
    console.log("The mlfb is: " + plcInforamtion.mlfb);
    if (!plcInforamtion.ip || !plcInforamtion.mlfb) {
        return {
            "success": "false",
            "err": "ip adress and mlfb are required."
        };
    }

    //Check if the plc already exists
    let everthingAdded = await CheckIfPlcNotExists(plcInforamtion.ip, plcInforamtion.mlfb)
        .then(() => {
            addPlcAndTriggerToDatabase(plcInforamtion, triggerList)
                .then(() => {
                    return true;
                })
                .catch(() => {
                    return false;
                });
        })
        .catch(() => {
            return false;
        })

    if (everthingAdded) {
        return Promise.resolve;
    }
    return Promise.reject;
    //add the trigger to database


    /*await plc.save().then((result) => {
        var jsonObjec = {"success": true, "plcId": result._id};
        console.log("The json object is: " + JSON.stringify(jsonObjec) + " " + JSON.parse(JSON.stringify(jsonObjec)));
        return JSON.stringify(jsonObjec);
    }).catch((err) => {
        return JSON.stringify({
            "success": false,
            "err": err
        });
    });*/
}

async function addPlcAndTriggerToDatabase(plcInforamtion, triggerList) {
    const plc = new Plc({
        _id: new mongoose.Types.ObjectId(),
        ip: plcInforamtion.ip,
        mlfb: plcInforamtion.mlfb
    });
    const plcId = await plc.save().then((result) => {
        return result._id;
    }).catch(() => {
        return 0;
    });
    if (plc == 0) {
        return Promise.reject();
    }
    console.log("The plcID is: " + plcId);

    let triggerAdded = await addTriggerToDatabase(triggerList, plcId)
        .then(() => {
            return true;
        })
        .catch(() => {
            return false;
        });
    if (triggerAdded) {
        return Promise.resolve;
    }
    return Promise.reject;
}

async function addTriggerToDatabase(triggerList, plcId) {

    console.log("The trigger list contains: " + JSON.stringify(triggerList));
    const trigger = new Trigger({
        _id: new mongoose.Types.ObjectId(),
        plcId: plcId,
        variable: triggerList.variable
    });
    const err = await trigger.save().then((result) => {
        return false;
    }).catch((err) => {
        console.log("err: " + err);
        return err;
    });

    if (err == false) {
        return Promise.resolve;
    }
    return Promise.reject;
}

async function CheckIfPlcNotExists(plcIp, plcMlfb) {
    let notExisting = false;
    notExisting = await Plc.findOne({ ip: plcIp, mlfb: plcMlfb })
        .then((result) => {
            if (result === null) {
                return true;
            }
            return false;
        }).catch((err) => {
            console.log("err: " + err);
            return false;
        });
    if (notExisting) {
        console.log("Must add PLC to DB");
        return Promise.resolve();
    }
    console.log("PLC already exists");
    return Promise.reject();
}

module.exports = addPlcInfromationToDb;