const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require('mongoose');

const Dependancy = require("../database/models/dependancies");
const Scripts = require("../database/models/scripts");
const Triggers = require("../database/models/triggers");

//set up the express app
const app = express();
app.use(bodyParser.json({ type: 'application/json' }));

const configRouter = express.Router();

//get the config
configRouter.get('/', (req, res) => {
    Dependancy.find()
        .exec()
        .then((result) => {
            res.status(200).send({
                sucess: 'true',
                message: 'depandancies between trigger and scripts retrieved successfully',
                dependancies: result
            })
        })
        .catch((err) => {
            res.status(500).send({
                sucess: 'false',
                message: 'internal error: ' + err,
            })
        });

})



//add config
configRouter.post('/', (req, res) => {
    //check if scriptId is in body
    if (!req.body.scriptId) {
        return res.status(400).send({
            sucess: 'false',
            message: 'scriptId is required'
        });
    }
    //check if triggerId is in body
    if (!req.body.triggerId) {
        return res.status(400).send({
            sucess: 'false',
            message: 'triggerId is required'
        })
    }

    //check if script with this id exists
    //check if trigger with this id exists
    //check if the config already exists

    CheckIfScriptExists(req, res)
        .then(() => {
            CheckIfTriggerExists(req, res)
                .then(() => {
                    CheckIfDependancyAlreadyExists(req, res)
                        .then(() => {
                            const dependancy = new Dependancy({
                                _id: mongoose.Types.ObjectId(),
                                triggerId: req.body.triggerId,
                                scriptId: req.body.scriptId
                            });
                            dependancy.save()
                                .then((result) => {
                                    return res.status(201).send({
                                        sucess: 'true',
                                        message: 'dependancy added successfully',
                                        result
                                    })
                                }).catch((err) => {
                                    return res.status(500).send({
                                        sucess: 'true',
                                        message: 'internal error: ' + err,
                                    })
                                });
                        }).catch()
                }).catch()
        }).catch();

})

//update config put (/config/:configId)
configRouter.put('/:configId', (req, res) => {
    const id = req.params.configId;
    //check if scriptId is in body
    if (!req.body.scriptId) {
        return res.status(400).send({
            sucess: 'false',
            message: 'scriptId is required'
        });
    }
    //check if triggerId is in body
    if (!req.body.triggerId) {
        return res.status(400).send({
            sucess: 'false',
            message: 'triggerId is required'
        })
    }

    CheckIfScriptExists(req, res)
        .then(() => {
            CheckIfTriggerExists(req, res)
                .then(() => {
                    CheckIfDependancyAlreadyExists(req, res)
                        .then(() => {
                            Dependancy.update({ _id: id }, { $set: { triggerId: req.body.triggerId, scriptId: req.body.scriptId } })
                                .exec()
                                .then((result) => {
                                    return res.status(200).send({
                                        sucess: 'true',
                                        message: 'dependancy updated successfully',
                                        result
                                    });
                                })
                                .catch((err) => {
                                    return res.status(500).send({
                                        sucess: 'false',
                                        message: 'database error: ' + err
                                    });
                                });
                        }).catch()
                }).catch();
        }).catch();
})

//delete config delete (/config/:configId)
configRouter.delete('/:configId', (req, res) => {

    const id = req.params.configId;
    Dependancy.remove({ _id: id })
        .exec()
        .then((result) => {
            return res.status(200).send({
                sucess: 'true',
                message: 'dependancy deleted successfully',
                result
            });
        })
        .catch((err) => {
            return res.status(500).send({
                sucess: 'false',
                message: 'database error: ' + err
            });
        });
})


async function CheckIfScriptExists(req, res) {
    let error = false;
    error = await Scripts.findById(req.body.scriptId)
        .exec()
        .then((result) => {
            if (result === null) {
                res.status(404).send({
                    sucess: 'false',
                    message: 'no script with id ' + req.body.scriptId + ' found'
                });
                return true;
            }
        })
        .catch((err) => {
            res.status(500).send({
                sucess: 'false',
                message: 'internal error: ' + err
            });
            return true;
        });
    if (error) {
        return Promise.reject();
    }
    return Promise.resolve();
}

async function CheckIfTriggerExists(req, res) {
    let error = false;
    error = await Triggers.findById(req.body.triggerId)
        .exec()
        .then((result) => {
            if (result === null) {
                res.status(404).send({
                    sucess: 'false',
                    message: 'no script with id ' + req.body.triggerId + ' found'
                });
                return true;
            }
        })
        .catch((err) => {
            res.status(500).send({
                sucess: 'false',
                message: 'internal error: ' + err,
            });
            return true;
        });
    if (error) {
        return Promise.reject();
    }
    return Promise.resolve();
}

async function CheckIfDependancyAlreadyExists(req, res) {
    let error = false;
    error = await Dependancy.find({ triggerId: req.body.triggerId, scriptId: req.body.scriptId })
        .exec()
        .then((result) => {
            if (result.length > 0) {
                res.status(400).send({
                    sucess: 'false',
                    message: 'this config exists already'
                });
                return true;
            }
        })
        .catch((err) => {
            res.status(500).send({
                sucess: 'false',
                message: 'internal error: ' + err,
            });
            return true;
        });
    if (error) {
        return Promise.reject();
    }
    return Promise.resolve();
}


module.exports = configRouter;