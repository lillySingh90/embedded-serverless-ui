const express = require("express");
const bodyParser = require("body-parser");

const Plc = require("./../database/models/plcs");

//set up the express app
const app = express();
app.use(bodyParser.json({ type: 'application/json' }));

const plcRouter = express.Router();

plcRouter.get('/', (req, res) => {
    Plc.find()
    .exec()
    .then((result) => {
        res.status(200).send({
            sucess: 'true',
            massage: 'all plcs retrieved successfully',
            plcs: result
        });
    })
    .catch((err) => {
        res.status(500).send({
            sucess: 'false',
            massage: 'database error: ' + err
        })
    });
    
});

module.exports = plcRouter;