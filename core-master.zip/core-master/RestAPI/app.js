const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const plcRouter = require("./plcRouter");
const triggerRouter = require("./triggerRouter");
const scriptRouter = require("./scriptRouter");
const configRouter = require('./configRouter');
const connectToDatabase = require('./../database/connectionDb');

connectToDatabase();

//set up the express app
const app = express();

app.use(cors());
app.use((req,res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    //res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
})

app.use(bodyParser.json({ type: 'application/json' }));
app.use('/triggers', triggerRouter);
app.use('/plcs', plcRouter);
app.use('/scripts', scriptRouter);
app.use('/config', configRouter);

/*app.all('/', (req,res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    //res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
})*/



//set up server
const PORT = 8421;
const IP = '139.23.163.211'

app.listen(PORT, IP, () => {
    console.log('server is now listening to port ' + PORT);
})
