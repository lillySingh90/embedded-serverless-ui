const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require('mongoose');

const Script = require("./../database/models/scripts");

//set up the express app
const app = express();
app.use(bodyParser.json({ type: 'application/json' }));

const scriptRouter = express.Router();

//get all scripts
scriptRouter.get('/', (req, res) => {
    Script.find()
        .exec()
        .then((result) => {
            res.status(200).send({
                sucess: 'true',
                massage: 'all scripts retrieved successfully',
                scripts: result
            })

        })
        .catch((err) => {
            res.status(500).send({
                sucess: 'false',
                massage: 'database error: ' + err
            })
        })
})

//get a specific script /scripts/2
scriptRouter.get('/:scriptID', (req, res) => {
    const id = req.params.scriptID;
    Script.findById(id)
        .exec()
        .then((result) => {
            if (result) {
                return res.status(200).send({
                    sucess: 'true',
                    message: 'script retrieved successfully',
                    result
                });
            }
            else {
                return res.status(404).send({
                    sucess: 'false',
                    message: 'script does not exists'
                });

            }
        })
        .catch((err) => {
            return res.status(500).send({
                sucess: 'false',
                message: 'database error: ' + err
            });
        });
});

//delete a script
scriptRouter.delete('/:scriptID', (req, res) => {
    const id = req.params.scriptID;
    Script.remove({ _id: id })
        .exec()
        .then((result) => {
            return res.status(200).send({
                sucess: 'true',
                message: 'script deleted successfully',
                result
            });
        })
        .catch((err) => {
            return res.status(500).send({
                sucess: 'false',
                message: 'database error: ' + err
            });
        });
})

//update a script
scriptRouter.put('/:scriptID', (req, res) => {
    const id = req.params.scriptID;
    if (!req.body.code) {
        return res.status(400).send({
            sucess: 'false',
            massage: 'code is required'
        });
    }
    if (!req.body.name) {
        return res.status(400).send({
            sucess: 'false',
            message: 'name is required'
        });
    }
    Script.update({_id: id}, {$set: { name: req.body.name, code: req.body.code}})
    .exec()
    .then((result) => {
        return res.status(200).send({
            sucess: 'true',
            message: 'script updated successfully',
            result
        });
    })
    .catch((err) => {
        return res.status(500).send({
            sucess: 'false',
            message: 'database error: ' + err
        });
    });  
    
})

//add a script
scriptRouter.post('/', (req, res) => {
    if (!req.body.code) {
        return res.status(400).send({
            sucess: 'false',
            message: 'code is required'
        });
    }
    if (!req.body.name) {
        return res.status(400).send({
            sucess: 'false',
            message: 'name is required'
        });
    }
    const script = new Script({
        _id: new mongoose.Types.ObjectId(),
        name: req.body.name,
        code: req.body.code
    });
    script.save().then((result) => {
        return res.status(201).send({
            sucess: 'true',
            message: 'script added successfully',
            result
        })
    }).catch((err) => {
        return res.status(500).send({
            sucess: 'true',
            message: 'database error: ' + err,
        })
    });

});

module.exports = scriptRouter;