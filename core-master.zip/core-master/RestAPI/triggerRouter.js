const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require('mongoose');

const Trigger = require('./../database/models/triggers');

//set up the express app
const app = express();
app.use(bodyParser.json({ type: 'application/json' }));

const triggerRouter = express.Router();

triggerRouter.get('/', (req, res) => {
    Trigger.find()
    .then(result => {
        res.status(200).send({
            sucess: 'true',
            massage: 'all trigger retrieved successfully',
            trigger: result
        })
    })
    .catch(err => {
        res.status(500).send({
            sucess: 'false',
            massage: 'error will retrieving the trigger: ' + err,
        })
    });
});


triggerRouter.post('/', (req, res) => {
    if (!req.body.plcId) {
        return res.status(400).send({
            sucess: 'false',
            message: 'plcId is required'
        });
    }
    if (!req.body.variable) {
        return res.status(400).send({
            sucess: 'false',
            message: 'variable is required'
        });
    }
    const trigger = new Trigger({
        _id: new mongoose.Types.ObjectId(),
        plcId: req.body.plcId,
        variable: req.body.variable
    });
    trigger.save().then((result) => {
        return res.status(201).send({
            sucess: 'true',
            message: 'trigger added successfully',
            result
        })
    }).catch((err) => {
        return res.status(500).send({
            sucess: 'true',
            message: 'database error: ' + err,
        })
    });

});


/*function getAllTrigger(res) {
    Trigger.find()
    .exec()
    .then(trigger => {
        res.status(200).send({
            sucess: 'true',
            massage: 'all trigger retrieved successfully',
            trigger: trigger
        })
    })
    .catch(err => {
        res.status(500).send({
            sucess: 'false',
            massage: 'error will retrieving the trigger: ' + err,
        })
    });
}*/
//get all triggers
/*triggerRouter.get('/', (req, res) => {
    r
})*/

//get trigger for a specific plc



module.exports = triggerRouter;